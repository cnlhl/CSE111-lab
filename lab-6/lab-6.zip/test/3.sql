.headers on
WITH qualified_parts_supp AS (
SELECT
    p_name AS qualified_part_name
FROM
(    
    SELECT
        part.p_name AS p_name,
        count(DISTINCT partsupp.ps_suppkey) AS africa_supplier_num
    FROM
        part
    JOIN
        partsupp ON part.p_partkey = partsupp.ps_partkey,
        supplier ON supplier.s_suppkey = partsupp.ps_suppkey,
        nation ON nation.n_nationkey = supplier.s_nationkey,
        region ON region.r_regionkey = nation.n_regionkey
    WHERE
        region.r_name = 'AFRICA'
    GROUP BY
        part.p_name
)
WHERE
    africa_supplier_num = 3
),
qualified_part_cust as(
SELECT
    DISTINCT part.p_name AS part_name
FROM
    orders
JOIN
    customer ON customer.c_custkey = orders.o_custkey,
    nation AS cus_nation ON cus_nation.n_nationkey = customer.c_nationkey,
    region AS cus_region ON cus_region.r_regionkey = cus_nation.n_regionkey,
    lineitem ON lineitem.l_orderkey = orders.o_orderkey,
    part ON lineitem.l_partkey = part.p_partkey
WHERE
    cus_region.r_name = 'ASIA'
)

SELECT part_name
FROM qualified_part_cust
WHERE part_name IN (SELECT qualified_part_name FROM qualified_parts_supp)
ORDER BY part_name;
