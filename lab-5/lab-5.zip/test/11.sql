.headers on
SELECT 
    sum(ps_supplycost) AS total_supply_cost
FROM
(
    SELECT
        DISTINCT partsupp.*
    FROM
        partsupp
    JOIN
        part ON part.p_partkey = partsupp.ps_partkey,
        (
        SELECT supplier.s_suppkey FROM supplier
        EXCEPT
        SELECT partsupp.ps_suppkey FROM partsupp,lineitem
        WHERE  partsupp.ps_partkey = lineitem.l_partkey AND 
                partsupp.ps_suppkey = lineitem.l_suppkey AND
                lineitem.l_extendedprice < 1000 AND
                strftime('%Y',lineitem.l_shipdate) = '1997'
        ) AS supplier ON partsupp.ps_suppkey = supplier.s_suppkey
    JOIN
        lineitem ON lineitem.l_partkey = partsupp.ps_partkey AND lineitem.l_suppkey = partsupp.ps_suppkey
    WHERE
        part.p_retailprice < 2000 AND
        strftime('%Y',lineitem.l_shipdate) = '1994'
);
    